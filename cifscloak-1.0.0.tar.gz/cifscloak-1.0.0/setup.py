from setuptools import setup

with open('README.md', 'r') as fh:
    long_description = fh.read()

setup(
    name='cifscloak',
    version='1.0.0',
    description='cifs mounting with encrypted passwords',
    long_description=long_description,
    author='Darren Chambers',
    author_email='dazchambers@gmail.com',
    url='https://github.com/sudoofus/cifscloak',
    install_requires=[
        'syslog',
	'getpass',
	'cryptography',
	'subprocess',
	'argparse',
	'sqlite3',
	'regex',
	'json',
	'time',
	'stat',
	'sys',
	'os',
    ],
    scripts=['cifscloak.py'],
)

