from setuptools import setup
import os, stat

with open('README.md', 'r') as fh:
    long_description = fh.read()

def _post_install():
    execpath = '/usr/local/bin/cifscloak.py'
    if os.name == 'posix' and os.path.exists(execpath):
        os.chmod(execpath, stat.S_IRWXU)

setup(
    name='cifscloak',
    version='1.0.12',
    description='cifs mounting with encrypted passwords',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Darren Chambers',
    author_email='dazchambers@gmail.com',
    url='https://github.com/sudoofus/cifscloak',
    install_requires=[
        'syslog',
	'getpass',
	'cryptography',
	'subprocess',
	'argparse',
	'sqlite3',
	'regex',
	'json',
	'time',
	'stat',
	'sys',
	'os',
    ],

    include_package_data=True,
    package_data={'':['cifscloak.service']},
    scripts=['cifscloak.py'],
)

_post_install()
